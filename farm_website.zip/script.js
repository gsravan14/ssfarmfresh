// ---------- Helpers ----------
    const qs = (s, el=document) => el.querySelector(s);
    const qsa = (s, el=document) => Array.from(el.querySelectorAll(s));

    const WA_NUMBER = '917382601453'; // +91 7382601453

    function waLink(message='Hi! I want to order farm-fresh milk.'){
      return `https://wa.me/${WA_NUMBER}?text=${encodeURIComponent(message)}`;
    }

    function openWA(message){
      const url = waLink(message);
      window.open(url, '_blank');
      // track clicks
      const k='ss_clicks';
      const clicks = Number(localStorage.getItem(k)||0) + 1;
      localStorage.setItem(k, clicks);
      updateStats();
    }

    function saveEnquiry(payload){
      const key='ss_enquiries';
      const arr = JSON.parse(localStorage.getItem(key)||'[]');
      arr.unshift(payload);
      localStorage.setItem(key, JSON.stringify(arr));
      updateStats();
    }

    function todayStr(){
      const d=new Date();
      return d.toISOString().slice(0,10);
    }

    function updateStats(){
      const arr = JSON.parse(localStorage.getItem('ss_enquiries')||'[]');
      const today = todayStr();
      const todayCount = arr.filter(x=>x.date.startsWith(today)).length;
      qs('#statToday').textContent = todayCount;
      qs('#statTotal').textContent = arr.length;
      qs('#statClicks').textContent = localStorage.getItem('ss_clicks')||'0';

      const list = arr.slice(0,6).map(x => `• ${x.name} (${x.phone}) — ${x.quantity}L ${x.frequency} @ ${x.time} — ${x.area}`).join('\\n');
      qs('#recentList').textContent = list || 'No enquiries yet.';
    }

    function loadCMS(){
      const cfg = JSON.parse(localStorage.getItem('ss_cms')||'null');
      if(!cfg) return;
      // apply to page
      if(cfg.heroTitle) qs('#heroTitle').textContent = cfg.heroTitle;
      if(cfg.heroSubtitle) qs('#heroSubtitle').textContent = cfg.heroSubtitle;
      if(cfg.pills){
        const wrap = qs('#whyPills');
        wrap.innerHTML = '';
        cfg.pills.split(',').map(s=>s.trim()).filter(Boolean).forEach(txt=>{
          const span = document.createElement('span');
          span.className='pill'; span.textContent=txt; wrap.appendChild(span);
        })
      }
      if(cfg.farmName){ qs('#farmName').textContent = cfg.farmName; qs('#footerName').textContent = cfg.farmName; }
      if(cfg.phone1){ qs('#phonePrimary').textContent = cfg.phone1; qs('#phonePrimary').href = `tel:+91${cfg.phone1.replace(/\D/g,'')}`; }
      if(cfg.phone2){ qs('#phoneSecondary').textContent = cfg.phone2; qs('#phoneSecondary').href = `tel:+91${cfg.phone2.replace(/\D/g,'')}`; }
      if(cfg.price){ qs('#pricePerL').textContent = `₹ ${cfg.price}`; }
      if(cfg.timing){ qs('#deliveryTiming').textContent = cfg.timing; }
      if(cfg.area){ qs('#serviceArea').textContent = cfg.area; }
      if(cfg.story){ qs('#ourStory').textContent = cfg.story; }

      // theme
      if(cfg.theme){ setTheme(cfg.theme); qs('#themeSelect').value = cfg.theme; }
    }

    function setTheme(name){
      const root = document.documentElement;
      if(name==='blue'){
        root.style.setProperty('--brand', '#145c9e');
        root.style.setProperty('--brand-2', '#78b9ff');
        root.style.setProperty('--ring', '#9ec9ff');
        root.style.setProperty('--accent', '#e7f1ff');
      } else if(name==='amber'){
        root.style.setProperty('--brand', '#b45309');
        root.style.setProperty('--brand-2', '#fbbf24');
        root.style.setProperty('--ring', '#f8d07a');
        root.style.setProperty('--accent', '#fff6db');
      } else {
        root.style.setProperty('--brand', '#1f7a1f');
        root.style.setProperty('--brand-2', '#7cc27c');
        root.style.setProperty('--ring', '#9ae69a');
        root.style.setProperty('--accent', '#f2fce2');
      }
    }

    // ---------- WhatsApp buttons ----------
    ['orderNowTop','orderNowHero','orderNowBottom','whatsFloat'].forEach(id=>{
      qs('#'+id).addEventListener('click', ()=> openWA('Hi! I want to order farm-fresh milk. Please help me with subscription.'))
    });

    // ---------- Form validation + Send on WhatsApp ----------
    qs('#enquiryForm').addEventListener('submit', (e)=>{
      e.preventDefault();
      // clear errors
      qsa('.error[data-err-for]').forEach(el=> el.textContent='');

      const name = qs('#name').value.trim();
      const phone = qs('#phone').value.replace(/\D/g,'');
      const address = qs('#address').value.trim();
      const quantity = qs('#quantity').value;
      const frequency = qs('#frequency').value;
      const time = qs('#time').value;
      const notes = qs('#notes').value.trim();

      let valid = true;
      if(name.length < 2){ valid=false; qs('[data-err-for="name"]').textContent='Please enter your full name.'; }
      if(!/^([6-9][0-9]{9})$/.test(phone)){ valid=false; qs('[data-err-for="phone"]').textContent='Enter a valid 10-digit Indian mobile starting with 6-9.'; }
      if(address.length < 8){ valid=false; qs('[data-err-for="address"]').textContent='Please add full address / landmark.'; }
      if(!quantity){ valid=false; qs('[data-err-for="quantity"]').textContent='Select a quantity.'; }
      if(!frequency){ valid=false; qs('[data-err-for="frequency"]').textContent='Select frequency.'; }
      if(!time){ valid=false; qs('[data-err-for="time"]').textContent='Select preferred time.'; }

      if(!valid) return;

      const payload = {
        date: new Date().toISOString(),
        name, phone: '+91 ' + phone.replace(/(\d{5})(\d{5})/,'$1 $2'),
        address, quantity, frequency, time, notes,
        area: (address.split(',')[1]||address).trim().slice(0,40)
      };
      saveEnquiry(payload);

      const message = `New milk enquiry:%0A%0A`+
        `Name: ${name}%0A`+
        `Phone: +91 ${phone}%0A`+
        `Address: ${encodeURIComponent(address)}%0A`+
        `Qty: ${quantity} L%0A`+
        `Frequency: ${frequency}%0A`+
        `Preferred Time: ${time}%0A`+
        (notes?`Notes: ${encodeURIComponent(notes)}%0A`:``)+
        `%0APlease guide me with next steps.`;

      openWA(decodeURIComponent(message));
      e.target.reset();
    });

    // ---------- Admin modal ----------
    const modal = qs('#adminModal');
    qs('#adminOpenBtn').addEventListener('click', ()=>{ modal.style.display='flex'; updateStats(); loadCMS(); });
    qs('#adminClose').addEventListener('click', ()=>{ modal.style.display='none'; });

    qs('#admSignIn').addEventListener('click', ()=>{
      const u = qs('#admUser').value.trim();
      const p = qs('#admPass').value;
      if(u==='admin' && p==='ssfarm2025'){
        qs('#adminLogin').style.display='none';
        qs('#adminTabs').style.display='block';
        updateStats();
        // preload CMS fields from current content or saved config
        const cfg = JSON.parse(localStorage.getItem('ss_cms')||'{}');
        qs('#cmsHeroTitle').value = cfg.heroTitle || qs('#heroTitle').textContent;
        qs('#cmsHeroSubtitle').value = cfg.heroSubtitle || qs('#heroSubtitle').textContent;
        qs('#cmsPills').value = cfg.pills || qsa('#whyPills .pill').map(p=>p.textContent).join(', ');
        qs('#cmsFarmName').value = cfg.farmName || qs('#farmName').textContent;
        qs('#cmsPhone1').value = cfg.phone1 || qs('#phonePrimary').textContent.replace(/\D/g,'').slice(-10);
        qs('#cmsPhone2').value = cfg.phone2 || qs('#phoneSecondary').textContent.replace(/\D/g,'').slice(-10);
        qs('#cmsPrice').value = cfg.price || qs('#pricePerL').textContent.replace(/\D/g,'');
        qs('#cmsTiming').value = cfg.timing || qs('#deliveryTiming').textContent;
        qs('#cmsArea').value = cfg.area || qs('#serviceArea').textContent;
        qs('#cmsStory').value = cfg.story || qs('#ourStory').textContent;
      } else {
        qs('#admError').textContent = 'Invalid credentials';
      }
    });

    // tab switching
    qsa('.admin-nav button').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        qsa('.admin-nav button').forEach(b=>b.classList.remove('active'));
        btn.classList.add('active');
        const t = btn.dataset.tab;
        qs('#tab-dash').style.display = (t==='dash')? 'block':'none';
        qs('#tab-cms').style.display = (t==='cms')? 'block':'none';
        qs('#tab-settings').style.display = (t==='settings')? 'block':'none';
      })
    })

    // CMS save/reset
    qs('#cmsSave').addEventListener('click', ()=>{
      const cfg = {
        heroTitle: qs('#cmsHeroTitle').value.trim(),
        heroSubtitle: qs('#cmsHeroSubtitle').value.trim(),
        pills: qs('#cmsPills').value.trim(),
        farmName: qs('#cmsFarmName').value.trim(),
        phone1: qs('#cmsPhone1').value.replace(/\D/g,''),
        phone2: qs('#cmsPhone2').value.replace(/\D/g,''),
        price: qs('#cmsPrice').value.trim(),
        timing: qs('#cmsTiming').value.trim(),
        area: qs('#cmsArea').value.trim(),
        story: qs('#cmsStory').value.trim(),
        theme: qs('#themeSelect').value
      };
      localStorage.setItem('ss_cms', JSON.stringify(cfg));
      loadCMS();
      alert('Saved! Site updated.');
    });

    qs('#cmsReset').addEventListener('click', ()=>{
      if(confirm('Reset site content to default?')){
        localStorage.removeItem('ss_cms');
        loadCMS();
        alert('Reset complete.');
      }
    });

    // Settings
    qs('#themeSelect').addEventListener('change', (e)=>{ setTheme(e.target.value); })

    // Data export/clear
    qs('#exportData').addEventListener('click', ()=>{
      const data = {
        enquiries: JSON.parse(localStorage.getItem('ss_enquiries')||'[]'),
        clicks: Number(localStorage.getItem('ss_clicks')||0),
        cms: JSON.parse(localStorage.getItem('ss_cms')||'{}')
      };
      const blob = new Blob([JSON.stringify(data, null, 2)], {type:'application/json'});
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download='ssfarm-data.json'; a.click();
      URL.revokeObjectURL(url);
    });

    qs('#clearData').addEventListener('click', ()=>{
      if(confirm('This will clear enquiries, clicks, and CMS settings saved in this browser. Continue?')){
        ['ss_enquiries','ss_clicks','ss_cms'].forEach(k=>localStorage.removeItem(k));
        updateStats();
        alert('All local data cleared.');
      }
    });


    
    // ---------- Admin Logout ----------
    qs('#logoutBtn').addEventListener('click', () => {
      // Hide admin tabs and show login form again
      qs('#adminTabs').style.display = 'none';
      qs('#adminLogin').style.display = 'grid';
      qs('#admUser').value = '';
      qs('#admPass').value = '';
      qs('#admError').textContent = '';

      // Keep modal open, show login screen again
      modal.style.display = 'flex';
    });


    // Footer year & initial CMS/theme
    qs('#year').textContent = new Date().getFullYear();
    loadCMS();
    updateStats();